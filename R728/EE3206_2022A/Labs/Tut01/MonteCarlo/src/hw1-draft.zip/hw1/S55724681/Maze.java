package hw1.S55724681;

import java.util.ArrayList;
import java.util.List;

public class Maze {
    public int xGoal,yGoal, dimensionSize;
    List<Rat> rats = new ArrayList<Rat>();
    
    public Maze() {
        this.dimensionSize = 7;
        this.xGoal = 7-1;
        this.yGoal = 7-1;
    }

    public Maze(int dimensionSize){
        this.dimensionSize = dimensionSize;
    }

    public void setGoal(int xGoal, int yGoal){
        this.xGoal = xGoal;
        this.yGoal = yGoal;
    }

    public void addRat(Rat rat){
        rats.add(rat);
    }

    public void clearRats(){
        rats.removeAll(rats);
    }
    
    public Rat setPos(Rat rat, int newX, int newY){ // Method to set the mouse's new position
        rat.xPos = newX;
        rat.yPos = newY;
        rat.visited.add(newX + "," + newY);
        return rat;
    }

    private boolean gameover(Rat rat){ // Check if the mouse is stuck or is at the exit
        if(rat.xPos == this.xGoal && rat.yPos == this.yGoal) {  // Check if it is at the exit
            rat.inside = false;
            return true;
        }
        // Then Check if it is stuck
        if(!validmove(rat, rat.xPos+1,rat.yPos) && !validmove(rat, rat.xPos-1,rat.yPos) && !validmove(rat, rat.xPos,rat.yPos+1) && !validmove(rat, rat.xPos,rat.yPos-1)) return true;

        return false; // Returns false if it is fine
    }

    private boolean validmove(Rat rat,int xPos, int yPos) {
        if ((xPos < 0) || (yPos < 0 )|| (xPos > dimensionSize-1) || (yPos > dimensionSize-1)) return false;
        if (rat.visited.contains(xPos + "," + yPos)) {
            return false;
        }
        return true;
    }

    private Rat move(Rat rat) { // Method to call if the mouse wants to move
        int newX = rat.xPos;
        int newY = rat.yPos;

        char direction = rat.roll();
        switch(direction) {
            case 'N' : newY = newY+1; break;
            case 'E' : newX = newX+1; break;
            case 'S' : newY = newY-1; break;
            case 'W' : newX = newX-1; break;
        }
    
        if(validmove(rat, newX, newY)) rat = setPos(rat, newX, newY);
        return rat;
    }

    public double ratEscape() { //Method to start the escape route search
        double successruns = 0;
        for(Rat rat : rats){
            while(!gameover(rat)){
                rat = move(rat);
            }
            if(!rat.inside) successruns++;
        }
        return successruns;
    } 
}
