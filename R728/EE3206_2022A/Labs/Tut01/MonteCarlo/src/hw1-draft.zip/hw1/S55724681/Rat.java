package hw1.S55724681;

import java.util.ArrayList;
import java.util.List;

public class Rat {
    public int xPos, yPos;
    public boolean inside;
    public List<String> visited = new ArrayList<String>();
    public String type = "Rat";
    public String name;

    public Rat(){ //Default Constructor
        int xPos = 0;
        int yPos = 0;
        this.xPos = xPos;
        this.yPos = yPos;
        this.inside = true;
        this.name = "Rat";
        this.visited.add(xPos + "," + yPos);
    }
    
    public Rat(int xPos, int yPos, String name){ //Default Constructor
        this.xPos = xPos;
        this.yPos = yPos;
        this.inside = true;
        this.name = name;
        this.visited.add(xPos + "," + yPos);
    }

    public char roll() {            // Roll the dice to decide the direction the mouse is going to
        double dice = Math.random();
        return (dice <= 0.3) ? 'N' : (dice <= 0.6) ? 'E' : (dice <= 0.8) ? 'S' : 'W';
    }
}