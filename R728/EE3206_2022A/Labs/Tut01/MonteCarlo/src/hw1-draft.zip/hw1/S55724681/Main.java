package hw1.S55724681;

public class Main {
    public static void main(String[] args) throws Exception {
        double successruns = 0;
        System.out.println("The Monte Carlo simulation result of one million runs:");
        int dimensionSize = 7;
        Maze maze = new Maze(dimensionSize);
        maze.setGoal(6,6);
        for(int i = 0; i < 1000000; i++){
            maze.clearRats();
            Rat ratatouille = new Rat();
            maze.addRat(ratatouille);
            successruns += maze.ratEscape();
        }
        System.out.println("Number of succesful escapes: " + successruns);
        System.out.println("Success Rate P: " + Math.floor(successruns/1000)/1000);
    }
}

