package ex1;

/**
 *
 * @author vanting
 */
class Utility {

    static int abs(int num) {
        return (num<0) ? (-num) : (num);
    }

}




