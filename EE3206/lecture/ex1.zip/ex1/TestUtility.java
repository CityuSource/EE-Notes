package ex1;

class TestUtility {

    /** Main method */
    public static void main(String[] args) {

        int a = -15;
        System.out.println("The absolute value of a is " + Utility.abs(a));
    }   
}


