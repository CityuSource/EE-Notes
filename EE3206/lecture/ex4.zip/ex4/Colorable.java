package ex4;

/**
 *
 * @author vanting
 */
public interface Colorable {

    abstract public void color();

}
