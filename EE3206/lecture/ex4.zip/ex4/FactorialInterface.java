package ex4;

/**
 *
 * @author vanting
 */
public interface FactorialInterface {

    public abstract int factorial(int n);

}
