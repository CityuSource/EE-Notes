#include "sleep.h"
#include <stdio.h>
#include "xil_io.h"
#include "xparameters.h"
#include "xbasic_types.h"
#include "xgpio.h"
#include "xstatus.h"
#define base_addr 0x44A00000 // 0x44A0_0000
//BASEADDR of PmodSSD IP register value obtained from
//xparameters.h or the Address Editor in Vivado
/*----- Variable declarations -----------*/

u8 first_digit;
u8 sec_digit;
int number;

/*----- function prototypes -------------*/

void display_digit(u8 value);
void displayNum(int numInput);
void display(void);
u8 decode(u8 digit);
void on_digit(u8 value);
void extract_digit(int number);

/*----- The main function -------------*/

int main() {
	for(int i = 0; i < 7; i++){
		displayNum(i);

		for(int i = 0; i < 20; i++){
			display();
		}
	}

	return 0;
}

void displayNum(int numInput){
	number = numInput; //the number to be displayed
	extract_digit(number);
	first_digit = decode(first_digit);
	sec_digit = decode(sec_digit);
}

/*----- Other functions -------------*/
void display(void){
	on_digit(1); //ON the first digit SSD
	display_digit(first_digit); //display first_digit
	usleep(10000); //10 milliseconds delay
	on_digit(2); //ON the second digit SSD
	display_digit(sec_digit); //display second_digit
	usleep(10000); //10 milliseconds delay
}

void display_digit(u8 value){
	Xil_Out32(base_addr, value);
};

u8 decode(u8 digit){
	u8 res;
	switch(digit){
		case 0: res = 0x3F; break; // SSD value for 0
		case 1: res = 0x06; break; // SSD value for 1
		case 2: res = 0x5B; break; // SSD value for 2
		case 3: res = 0x4F; break; // SSD value for 3
		case 4: res = 0x66; break; // SSD value for 4
		case 5: res = 0x6D; break; // SSD value for 5
		case 6: res = 0x7D; break; // SSD value for 6
		case 7: res = 0x07; break; // SSD value for 7
		case 8: res = 0x7F; break; // SSD value for 8
		case 9: res = 0x6F; break; // SSD value for 9
	}
	return res;
}

void on_digit(u8 value){
	if (value == 1) {
		first_digit= (first_digit & 0x7F);
	} else{
		sec_digit = (sec_digit | 0x80);
	}
}

void extract_digit(int number){
	first_digit =0;
	sec_digit =0;

	if(number>0)
	{
		sec_digit = number/10;
		first_digit = number%10;
	}
}

