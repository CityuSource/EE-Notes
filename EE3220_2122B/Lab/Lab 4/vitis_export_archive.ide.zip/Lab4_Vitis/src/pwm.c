#include <stdio.h>
#include "xil_io.h"
#include "xparameters.h"
#include "xbasic_types.h"
#include "xstatus.h"
#include "sleep.h"
#define slv_reg0 0x44A00000  //BASEADDR of pwm_controller registers. This value is obtained from xparameters.h or the Address Editor in Vivado

void pwmRGB(Xuint32 *r, Xuint32 *g, Xuint32 *b, int rVal, int gVal, int bVal, int duration){
    *r = (u32) rVal;     //red color value
    *g = (u32) gVal;   //green color value
    *b = (u32) bVal;   //blue color value
    usleep(duration);

}

int main()
{
    Xuint32      *pwm_1_dc_count; // declare pointers;
    Xuint32      *pwm_2_dc_count;
    Xuint32      *pwm_3_dc_count;
    Xuint32      *enable_reg;

// initialize pointers to the address of the axi peripheral slave registers
    enable_reg = (u32 *)(slv_reg0);
    pwm_1_dc_count = (u32 *) (slv_reg0 + 4);
    pwm_2_dc_count = (u32 *)(slv_reg0 + 8);
    pwm_3_dc_count = (u32 *)(slv_reg0 + 12);

// enable the PWM outputs and set the duty cycle counter values for the registers
    *(enable_reg) = 0x07; // enable all the 3 pwm outputs

    while(1){
    	pwmRGB(pwm_1_dc_count, pwm_2_dc_count, pwm_3_dc_count, 255, 0, 0, 200000);
    	pwmRGB(pwm_1_dc_count, pwm_2_dc_count, pwm_3_dc_count, 255, 128, 0, 200000);
    	pwmRGB(pwm_1_dc_count, pwm_2_dc_count, pwm_3_dc_count, 255, 255, 0, 200000);
    	pwmRGB(pwm_1_dc_count, pwm_2_dc_count, pwm_3_dc_count, 128, 255, 0, 200000);
    	pwmRGB(pwm_1_dc_count, pwm_2_dc_count, pwm_3_dc_count, 0, 255, 0, 200000);
    	pwmRGB(pwm_1_dc_count, pwm_2_dc_count, pwm_3_dc_count, 0, 255, 128, 200000);
    	pwmRGB(pwm_1_dc_count, pwm_2_dc_count, pwm_3_dc_count, 0, 255, 255, 200000);
    	pwmRGB(pwm_1_dc_count, pwm_2_dc_count, pwm_3_dc_count, 0, 128, 255, 200000);
    	pwmRGB(pwm_1_dc_count, pwm_2_dc_count, pwm_3_dc_count, 0, 0, 255, 200000);
    	pwmRGB(pwm_1_dc_count, pwm_2_dc_count, pwm_3_dc_count, 127, 0, 255, 200000);
    	pwmRGB(pwm_1_dc_count, pwm_2_dc_count, pwm_3_dc_count, 255, 0, 255, 200000);
    	pwmRGB(pwm_1_dc_count, pwm_2_dc_count, pwm_3_dc_count, 255, 0, 127, 200000);
    }

    return 0;
 }

