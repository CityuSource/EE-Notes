/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ex5;

/**
 *
 * @author vanting
 * @param <K>
 * @param <V>
 */
public interface Pair<K, V> {

    public K getKey();

    public V getValue();
}
